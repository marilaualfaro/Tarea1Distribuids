// ejemplo1_6.js
function respondText (req, res) { 
  res.setHeader('Content-Type', 'text/plain') 
  res.end('hi')
}

/*function respondJson (req, res) {
  res.json({ text: 'hi', numbers: [1, 2, 3] })
}*/

function respondEcho (req, res) { 
  const { input = '' } = req.query
  res.json({
    normal: input,
    shouty: input.toUpperCase(),
    characterCount: input.length,
    backwards: input
      .split('')
      .reverse()
      .join('')
  }) 
}

function respondStatic (req, res) {
  const filename = `${__dirname}/public/${req.params[0]}` 
  fs.createReadStream(filename)
    .on('error', () => respondNotFound(req, res))
    .pipe(res) 
}

function respondNotFound (req, res) {
  res.writeHead(404, 
    { 'Content-Type': 'text/plain' }) 
  res.end('Not Found')
}


function convertTemp(req, res) {
const { input = '' } = req.query
res.json({
farenheit: input,
celcius:(input - 32) * 5/9
})
}

function respondJson (req, res) {
  const filename = `../public/archivo.json`
  let json = fs.readFileSync(filename);
  let info = JSON.parse(json);
  res.json(info)
}

function saveText (req, res) {
	const { text = '' } = req.query
	const filename = `../public/string.txt`
	var data = fs.readFileSync(filename, 'utf8');
	fs.truncate(filename, 0, function(){console.log('done')})
	fs.appendFile(filename, data.toString() + text, function (err) {
		if (err) {
		res.end(err)
		} else {
		res.end(data.toString() + text)
	}
})
}

function respondMk (req, res) {
	const { text = '' } = req.query
	var data = fs.readFileSync('../public/text_prueba.txt', 'utf8');
	fs.truncate('../public/text_prueba.txt', 0, function(){console.log('done')})
	fs.appendFile('../public/text_prueba.txt', data.toString() + text, function (err) {
	if (err) {
	res.end(err)
	} else {
	res.end(data.toString() + text)
	}
})
}

const fs = require('fs')
const express = require('express')
const port = process.env.PORT || 1337 
const app = express()
app.get('/', respondText)
app.get('/json/*', respondJson)
app.get('/echo', respondEcho)
app.get('/static/*', respondStatic)
app.get('/convertTemp', convertTemp)
app.get('/saveText', respond_file_text)
app.listen(port, () => console.log(`Server listening on port ${port}`))